SELECT DISTINCT GROUP_CONCAT(p.ProductName, ', ')
OVER (ORDER BY p.Id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
FROM Product AS p
INNER JOIN OrderDetail AS od ON od.ProductId = p.Id
INNER JOIN 'Order' AS o ON o.Id = od.OrderId
INNER JOIN Customer AS c ON c.Id = o.CustomerId
WHERE c.CompanyName = 'Queen Cozinha' AND o.OrderDate LIKE '%2014-12-25%';
