SELECT o.Id, o.ShipCountry, CASE WHEN o.ShipCountry IN ('USA', 'Mexico', 'Canada')
THEN 'NorthAmerica'
ELSE 'OtherPlace'
END ShipPlaces
FROM 'Order' AS o
WHERE o.Id >= 15445
ORDER by o.Id ASC 
LIMIT 20;