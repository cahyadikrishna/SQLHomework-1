SELECT s.CompanyName,
ROUND(ROUND(COUNT(CASE WHEN JULIANDAY(ShippedDate) > JULIANDAY(RequiredDate) THEN 'late' END)) / ROUND(COUNT(o.Id)) * 100, 2)
FROM Shipper AS s, 'Order' AS o 
WHERE s.id = o.ShipVia
GROUP BY s.id
ORDER BY s.CompanyName DESC;