SELECT c.CategoryName, COUNT(p.UnitsOnOrder), ROUND(AVG(p.UnitPrice), 2), MIN(p.UnitPrice), MAX(p.UnitPrice), SUM(p.UnitsOnOrder)
FROM Category AS c, Product AS p
WHERE c.Id = p.CategoryId
GROUP BY c.CategoryName
ORDER BY c.Id;