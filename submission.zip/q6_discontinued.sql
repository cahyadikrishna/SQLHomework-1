WITH result AS (
    SELECT p.ProductName, c.CompanyName, c.ContactName, ROW_NUMBER() OVER(PARTITION BY p.ProductName ORDER BY o.OrderDate ASC) AS num
    FROM Customer AS c
    INNER JOIN 'Order' AS o ON o.CustomerId = c.Id
    INNER JOIN OrderDetail AS od ON od.OrderId = o.Id
    INNER JOIN Product AS p ON p.Id = od.ProductId
    WHERE p.Discontinued = 1
)
SELECT ProductName, CompanyName, ContactName FROM result
WHERE num = 1;
