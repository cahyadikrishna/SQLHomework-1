SELECT o.Id, o.Orderdate, 
LAG(o.Orderdate, 1, 0) OVER(ORDER BY o.Orderdate ASC), 
ROUND(JULIANDAY(o.Orderdate) - JULIANDAY(LAG(o.Orderdate, 1, 0) OVER(ORDER BY o.Orderdate ASC)), 2)
FROM 'Order' AS o, Customer AS c
WHERE o.CustomerId = c.Id AND c.Id = 'BLONP'
ORDER BY o.Orderdate ASC
LIMIT 10;