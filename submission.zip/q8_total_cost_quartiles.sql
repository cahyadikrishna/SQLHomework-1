SELECT IFNULL(c.CompanyName, 'MISSING_NAME'), o.CustomerId, ROUND(od.UnitPrice + od.Quantity, 2)
FROM Customer AS c
INNER JOIN 'Order' AS o ON o.CustomerId = c.Id
INNER JOIN OrderDetail AS od ON od.OrderId = o.Id
GROUP BY c.Id
ORDER BY ROUND(od.UnitPrice + od.Quantity, 2);
