SELECT r.RegionDescription, e.FirstName, e.LastName, e.BirthDate
FROM Employee AS e
INNER JOIN EmployeeTerritory AS et ON et.EmployeeId = e.Id
INNER JOIN Territory AS t ON t.Id = et.TerritoryId
INNER JOIN Region AS r ON r.Id = t.RegionId
GROUP BY r.Id
HAVING MIN(e.BirthDate);
